package com.example.hotel.services;

public class ReservationService {
}
