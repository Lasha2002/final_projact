package com.example.hotel.classes;

import lombok.Data;

@Data
public class Hotel {
    public  static  String hotelName;
    public  static  int numberOfRooms;
    public  static  double rate;
    public  static  int hotelCapacity;
    public  static  double roomPrice;
}
