package com.example.hotel.classes;

import lombok.Data;

@Data
public class Reservation {
}
