package com.example.hotel.services;

import com.example.hotel.classes.Hotel;

public class HotelService extends Hotel {

}
